// Native, locally bundled implementation of Figma Healthcare section 6045:10091.
let healthObserver;
function renderHealth(id){
 healthObserver?.disconnect();screen.className='health-screen';screen.innerHTML='';
 const height=id==='question'?1305:932, canvas=document.createElement('div');canvas.className='health-canvas';canvas.style.height=height+'px';screen.append(canvas);
 const place=(tag,cls,x,y,w,h,html='')=>{const el=document.createElement(tag);el.className=cls;Object.assign(el.style,{left:x+'px',top:y+'px',width:w+'px',...(h?{height:h+'px'}:{})});el.innerHTML=html;canvas.append(el);return el};
 const asset=(node,name)=>healthAssets[node][name];
 const img=(node,name,x,y,w,h,cls='')=>{const e=place('img','hf-image '+cls,x,y,w,h);e.src=asset(node,name);e.alt='';return e};
 const text=(html,x,y,w=390,size=16,cls='')=>{const e=place('div','hf-text '+cls,x,y,w,0,html);e.style.fontSize=size+'px';return e};
 const btn=(label,x,y,w,h,action,cls='')=>{const e=place('button','hf-button '+cls,x,y,w,h,label);e.type='button';e.onclick=action;return e};
 const picbutton=(node,name,label,x,y,w,h,action)=>{const b=btn('',x,y,w,h,action);b.setAttribute('aria-label',label);b.innerHTML=`<img src="${asset(node,name)}" alt="">`;return b};
 const title=t=>text(t,20,84,390,32,'hf-title');
 const home=()=>go('health',{root:true});
 const primary=(label,y,action,x=20,w=390)=>btn(label,x,y,w,64,action,'hf-primary');
 const avatar=Object.keys(healthAssets['10220']).find(k=>k.endsWith('L12'));
 text('9:41',59,20,44,17,'hf-time');img('10220','imgDarkFalse',105,23,14,14);place('div','hf-island',154,10,122,36);img('10220','imgSignal',301,23,18,14);img('10220','imgProperty1HotspotDarkFalse',329,23,18,14);img('10220','imgChargeStatusMediumDarkFalse',357,23,27,14);img('10220','imgVector2',357,23,10,14);if(id!=='question')img('10220','imgLens',252,22,12,12);else canvas.querySelector('.hf-island').remove();text('32',363,21,20,11,'hf-battery');place('div','hf-homebar',155,height-13,120,5);
 const confirm=(heading,copy)=>{
  const overlay=place('div','hf-overlay',0,0,430,height);overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label',heading);
  const top=Math.min(height-270,phone.scrollTop/(phone.clientWidth/430)+466);
  overlay.innerHTML=`<div class="hf-popover" style="top:${top}px"><h2>${heading}</h2><p>${copy}</p><button type="button">Got it</button></div>`;
  [...canvas.children].filter(e=>e!==overlay).forEach(e=>e.inert=true);
  const b=overlay.querySelector('button');b.onclick=home;b.focus({preventScroll:true});overlay.onkeydown=e=>{if(e.key==='Tab'){e.preventDefault();b.focus({preventScroll:true})}};
 };
 if(id==='health'){
  title('Healthcare');place('div','hf-petpill',269,75,141,43);img('10220',avatar,269,75,43,43,'hf-avatar');text(esc(pet.name),319,85,65,18);img('10220','imgChevronRight',378,84,24,24,'hf-down');
  const search=place('input','hf-search',20,141,390,36);search.placeholder='Search for questions';search.setAttribute('aria-label','Search questions');img('10220','imgIcon1',28,151,16,16);img('10220','imgIcon',386,151,16,16);
  btn('Ask<br>Professionals',19,209,187,92,()=>ask(),'hf-feature');img('10220','imgQA1',144,226,58,58,'hf-passive');
  btn('AI Diagnosis',223,209,187,92,()=>go('diagnosis'),'hf-feature');img('10220','imgCamera1',349,228,49,55,'hf-passive');
  text('My Questions',20,327,350,20,'hf-section');img('10220','imgChevronRight1',386,327,24,24);
  questions.slice(-2).forEach((q,i)=>{const y=365+i*134;const card=place('article','hf-question-card',20,y,390,120);card.dataset.search=(q.title+' '+q.text).toLowerCase();card.innerHTML=`<h3>${esc(q.title)}</h3><p>${esc(q.text)}</p><small>${esc(q.date||'Just now')}</small><i></i>`});
  search.oninput=()=>canvas.querySelectorAll('.hf-question-card').forEach(c=>c.style.opacity=c.dataset.search.includes(search.value.toLowerCase())?'1':'.25');
  text('My Diagnosis',20,645,350,20,'hf-section');img('10220','imgChevronRight1',386,643,24,24);
  const rail=place('div','hf-diagnosis-rail',19,681,411,167);
  const scans=pet.savedScan?[['Eye Scan','10331','img168117125406382','Just now'],['Skin Scan','10220','imgRectangle68','1 day ago'],['Teeth Scan','10220','imgRectangle69','2 days ago']]:[['Skin Scan','10220','imgRectangle68','1 day ago'],['Teeth Scan','10220','imgRectangle69','2 days ago'],['Skin Scan','10220','imgRectangle70','1 day ago']];
  scans.forEach(([name,node,key,date])=>{const c=document.createElement(name==='Eye Scan'?'button':'article');c.className='hf-scan-card';c.innerHTML=`<div class="hf-scan-photo"><img src="${asset(node,key)}" alt="${name}" class="${key==='imgRectangle68'?'hf-skin':''}"></div><strong>${name}</strong><small>${date}</small>`;if(name==='Eye Scan')c.onclick=()=>go('result');rail.append(c)});
  place('div','hf-nav-background',0,856,430,76);img('10220','imgEllipse28',212,875,25,25);
  [['food','FOOD','imgVector1',79],['health','HEALTH','imgVector',215],['profile','PROFILE','imgPetIcon',351]].forEach(([dest,label,key,x])=>{const b=btn('',x-53,863,106,62,()=>go(dest,{root:true}),'hf-tab');b.setAttribute('aria-label',label);b.innerHTML=`<img src="${asset('10220',key)}" alt=""><span>${label}</span>`});
 }
 if(id==='diagnosis'){
  title('AI Diagnosis');picbutton('10092','imgX','Close scan',380,84,30,30,home);
  text('This feature allows you to use your camera to scan parts of your dog for a quick health assessment.',20,140,389);
  text('To get started, select the specific area of your dog you wish to scan.',20,196,389);
  [['Ears','imgEllipse16'],['Eyes','imgEllipse13'],['Nose','imgEllipse15'],['Teeth & gums','imgEllipse12'],['Paws','imgEllipse14'],['Skin & coat','imgEllipse17']].forEach(([name,key],i)=>{const x=i%2?223:20,y=294+Math.floor(i/2)*155;const b=btn('',x,y,187,139,()=>{if(name==='Eyes'){selectedArea=name;b.focus()}},'hf-area '+(name==='Eyes'?'selected':''));b.setAttribute('aria-label',name);b.setAttribute('aria-pressed',String(name==='Eyes'));b.innerHTML=`<img src="${asset('10282',key)}" alt=""><span>${name}</span>`;if(name!=='Eyes'){b.setAttribute('aria-disabled','true');b.title='The supplied prototype connects the Eyes scan.'}});
  primary('Next',838,()=>go('camera'));
 }
 if(id==='camera'){
  text('Take a photo',54,84,356,32,'hf-title');picbutton('10318','imgChevronLeft','Back to scan selection',8,88,24,24,()=>go('diagnosis',{replace:true}));
  text('Ensure good lighting and a clear view. Our AI needs a sharp image to analyze effectively.',20,140,389);
  img('10318','img168117125406381',0,226,430,466);img('10318','imgEllipse46',112,461,151,152);img('10318','imgEllipse47',97,445,182,183);
  picbutton('10318','imgEllipse13','Capture sample photo',168,757,95,95,()=>go('result'));
  img('10318','imgVector1',88,792,25,27);img('10318','imgVector2',318,787,35,35);
 }
 if(id==='result'){
  title('Results');text('What we Found',20,140,389,20,'hf-section');text('Our AI reviewed the images of your dog’s eyes and observed:',20,168,389);
  img('10331','img168117125406382',121,228,187,128,'hf-result-photo');img('10331','imgVector61',175,298,48,32);
  text('<b>Eye Clarity:</b> Eyes are clear, with no discharge or cloudiness.<br><b>Potential Issues:</b> Slight redness observed. This could be an environmental irritant or the beginning of an infection.',20,384,389);
  place('div','hf-divider',28,519,375,1);text('What to do',20,542,389,20,'hf-section');text('Keep the eye area clean. If redness or discharge continues, consult a vet for a closer examination.',20,570,389);
  text('The AI diagnostics only provide a preliminary assessment. It’s essential to follow up with your vet for a more comprehensive health evaluation.<br>Regular care and preventive measures can significantly impact your dog’s health and happiness.',21,661,389,14);
  btn('Test Again',21,837,186,64,()=>go('camera',{replace:true}),'hf-secondary');primary('Save result',837,()=>{pet.savedScan=true;confirm('Results Saved!','You can review past results anytime in the “My Diagnosis” section')},223,187);
 }
 if(id==='question'){
  title('Ask new question');picbutton('10092','imgX','Close question',380,84,30,30,home);
  text('Pawsome provides support for minor health issues and is not a substitute for professional veterinary care. For emergencies, contact a veterinarian immediately. Use this tool for informational purposes only.',20,140,393);
  text('For',20,270,390,20,'hf-section');let chosen='Momo';
  [['Momo',74,healthAssets['10220'][avatar]],['Haru',237,healthAssets['10092'].imgRemoval1]].forEach(([name,x,src])=>{const b=btn('',x,304,120,120,()=>{chosen=name;canvas.querySelectorAll('.hf-pet-option').forEach(e=>{e.classList.toggle('selected',e.dataset.pet===name);e.setAttribute('aria-pressed',String(e.dataset.pet===name))})},'hf-pet-option '+(name==='Momo'?'selected':''));b.dataset.pet=name;b.setAttribute('aria-label',name);b.setAttribute('aria-pressed',String(name==='Momo'));b.innerHTML=`<img src="${src}" alt=""><span>${name}</span>`});
  const field=(name,y,h,tag)=>{text(name,20,y,390,20,'hf-section');const e=place(tag,'hf-field',20,y+36,390,h);e.setAttribute('aria-label',name);return e};
  const category=field('Category',458,48,'select');category.innerHTML='<option>Skin and Care</option>';category.value=questionDraft.category;
  const subject=field('Subject',566,48,'input');subject.value=questionDraft.subject;subject.oninput=()=>questionDraft.subject=subject.value;
  const description=field('Description',674,150,'textarea');description.value=questionDraft.description;description.oninput=()=>questionDraft.description=description.value;
  const upload=place('label','hf-upload',20,876,390,64,`<img src="${asset('10092','imgCirlcePlus')}" alt=""><span>Add File</span><input type="file" accept="image/*" aria-label="Upload photo">`);upload.querySelector('input').onchange=e=>{upload.querySelector('span').textContent=e.target.files[0]?.name||'Add File'};
  text('Screening Survey',20,964,390,20,'hf-section');text('Provide more details by answering this survey to help professionals better understand the problem',21,992,389,14);
  btn('Take the survey',32,1038,366,48,()=>toast('The survey is not connected in the Figma prototype.'),'hf-survey');
  text('Visibility',20,1110,390,20,'hf-section');['Public','Private'].forEach((v,i)=>{const b=btn(v,20+i*140,1146,114,32,()=>{questionDraft.visibility=v;canvas.querySelectorAll('.hf-visibility').forEach(e=>{e.classList.toggle('selected',e.textContent===v);e.setAttribute('aria-pressed',String(e.textContent===v))})},'hf-visibility '+(v===questionDraft.visibility?'selected':''));b.setAttribute('aria-pressed',String(v===questionDraft.visibility))});
  primary('Post your question',1207,()=>{questions.push({title:subject.value.trim()||'New question',text:description.value.trim(),date:'Just now',owner:petIndex,visibility:questionDraft.visibility,pet:chosen});confirm('Question posted!','You can edit your question anytime to add more details')},21,389);
 }
 const resize=()=>{canvas.style.transform=`scale(${phone.clientWidth/430})`;screen.style.height=height*phone.clientWidth/430+'px'};healthObserver=new ResizeObserver(resize);healthObserver.observe(phone);resize();
}
