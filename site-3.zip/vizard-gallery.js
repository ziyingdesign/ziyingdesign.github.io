(() => {
  const dialog = document.createElement('dialog');
  dialog.className = 'viz-lightbox';
  dialog.setAttribute('aria-label', 'Original design image');
  const close = document.createElement('button');
  close.type = 'button'; close.textContent = '×'; close.setAttribute('aria-label', 'Close image');
  const image = document.createElement('img');
  const caption = document.createElement('p');
  dialog.append(close, image, caption); document.body.append(dialog);
  close.addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  document.querySelectorAll('.viz-image').forEach(button => {
    button.addEventListener('click', () => {
      const original = button.querySelector('img');
      image.src = original.currentSrc || original.src; image.alt = original.alt;
      image.classList.toggle("exploration-monochrome", original.classList.contains("exploration-monochrome"));
      caption.textContent = original.alt + ' · Original Figma / FigJam export';
      dialog.showModal(); dialog.scrollTop = 0;
    });
  });
})();

// Complete persona tabs, including keyboard navigation.
(() => {
 const tabs = [...document.querySelectorAll('.persona-tabs [role="tab"]')];
 function select(tab) {
   tabs.forEach(t => { const active = t === tab; t.setAttribute('aria-selected', String(active)); t.tabIndex = active ? 0 : -1; document.getElementById(t.getAttribute('aria-controls')).hidden = !active; });
 }
 tabs.forEach((tab, i) => {
   tab.addEventListener('click', () => select(tab));
   tab.addEventListener('keydown', event => {
     let next;
     if (event.key === 'ArrowRight') next = (i + 1) % tabs.length;
     if (event.key === 'ArrowLeft') next = (i + tabs.length - 1) % tabs.length;
     if (event.key === 'Home') next = 0;
     if (event.key === 'End') next = tabs.length - 1;
     if (next !== undefined) { event.preventDefault(); select(tabs[next]); tabs[next].focus(); }
   });
 });
 const gif = document.querySelector('.ui-gif');
 const toggle = document.querySelector('.animation-toggle');
 if (!gif || !toggle) return;
 const animated = gif.src;
 const poster = new URL('results-walkthrough-poster.png', animated).href;
 function pause(paused) {
   gif.src = paused ? poster : animated;
   toggle.textContent = paused ? 'Play animation' : 'Pause animation';
   toggle.setAttribute('aria-pressed', String(paused));
 }
 pause(window.matchMedia('(prefers-reduced-motion: reduce)').matches);
 toggle.addEventListener('click', () => pause(toggle.getAttribute('aria-pressed') !== 'true'));
})();
(() => {
 const tabs=[...document.querySelectorAll('.before-map-tabs [role="tab"]')];
 function activate(tab){tabs.forEach(t=>{const active=t===tab;t.setAttribute('aria-selected',String(active));t.tabIndex=active?0:-1;document.getElementById(t.getAttribute('aria-controls')).hidden=!active;});}
 tabs.forEach((tab,i)=>{tab.addEventListener('click',()=>activate(tab));tab.addEventListener('keydown',event=>{let n;if(event.key==='ArrowRight')n=(i+1)%tabs.length;if(event.key==='ArrowLeft')n=(i+tabs.length-1)%tabs.length;if(n!==undefined){event.preventDefault();activate(tabs[n]);tabs[n].focus();}});});
})();
