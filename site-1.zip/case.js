const sections = document.querySelectorAll('section[id]');
const links = document.querySelectorAll('.case-nav a');
if ('IntersectionObserver' in window) {
 const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => { if(entry.isIntersecting) links.forEach(link => {
   if(link.hash === '#'+entry.target.id) link.setAttribute('aria-current','true');
   else link.removeAttribute('aria-current');
  }); });
 },{rootMargin:'-10% 0px -65% 0px'});
 sections.forEach(section=>observer.observe(section));
}
document.querySelectorAll('video').forEach(video=>video.addEventListener('play',()=>{
 document.querySelectorAll('video').forEach(other=>{if(other!==video)other.pause();});
}));

// Start on viewport entry; native controls remain available for manual playback.
const videos = [...document.querySelectorAll('video')];
const inView = new Set();
const resumeOnVisible = new Set();
const playMuted = video => {
 video.muted = true;
 const attempt = video.play();
 if (attempt) attempt.catch(() => {}); // Native play control is the fallback.
};
if ('IntersectionObserver' in window) {
 const videoObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
   const video = entry.target;
   const visible = entry.isIntersecting && entry.intersectionRatio >= 0.25;
   if (visible && !inView.has(video)) {
    inView.add(video);
    if (!document.hidden && !video.ended) playMuted(video);
   } else if (!visible) {
    inView.delete(video);
    resumeOnVisible.delete(video);
    video.pause();
   }
  });
 }, {threshold: [0, 0.25]});
 videos.forEach(video => videoObserver.observe(video));
 document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
   videos.forEach(video => {
    if (!video.paused) resumeOnVisible.add(video);
    video.pause();
   });
  } else {
   resumeOnVisible.forEach(video => {
    if (inView.has(video) && !video.ended) playMuted(video);
   });
   resumeOnVisible.clear();
  }
 });
}

// Case-study motion: content stays readable before JavaScript and with reduced motion.
(() => {
 const preference = matchMedia('(prefers-reduced-motion: reduce)');
 const active = new Set();
 const counted = new Set();
 const play = (element, frames, options) => {
  if (preference.matches) return;
  const animation = element.animate(frames, options);
  active.add(animation);
  animation.finished.catch(() => {}).finally(() => active.delete(animation));
 };
 const reveal = (element, delay = 0) => play(element,
  [{opacity:0, transform:'translateY(20px)'},{opacity:1, transform:'translateY(0)'}],
  {duration:650, delay, easing:'cubic-bezier(.2,.7,.2,1)', fill:'backwards'});
 const count = element => {
  const final = element.innerHTML;
  const value = parseInt(element.textContent,10);
  if (!Number.isFinite(value) || element.textContent.includes('→')) return;
  const label = element.textContent;
  element.setAttribute('aria-label',label);
  let start;
  const finish = () => {element.innerHTML=final;counted.delete(finish)};
  counted.add(finish);
  const tick = time => {
   if(preference.matches){finish();return}
   start ??= time;
   const progress=Math.min((time-start)/1100,1);
   element.textContent=Math.round(value*(1-Math.pow(1-progress,3)))+'%';
   if(progress<1)requestAnimationFrame(tick);else finish();
  };
  requestAnimationFrame(tick);
 };
 if('IntersectionObserver' in window){
  const observer = new IntersectionObserver(entries => entries.forEach(({target,isIntersecting})=>{
   if(!isIntersecting)return;
   observer.unobserve(target);
   if(preference.matches)return;
   if(target.matches('.funnel')){
    target.querySelectorAll('.funnel-bars i').forEach((bar,i)=>play(bar,
     [{transform:'scaleY(0)'},{transform:'scaleY(1)'}],
     {duration:850,delay:i*90,easing:'cubic-bezier(.2,.7,.2,1)',fill:'backwards'}));
   }else if(target.matches('.impact-strip,.outcomes')){
    [...target.children].forEach((card,i)=>reveal(card,i*100));
    target.querySelectorAll('strong').forEach(count);
   }else if(target.matches('.user-columns,.concepts,.business-decline')){
    [...target.children].forEach((card,i)=>reveal(card,i*110));
    target.querySelectorAll('svg path').forEach(path=>{
     const length=path.getTotalLength();
     play(path,[{strokeDasharray:`${length}`,strokeDashoffset:length},{strokeDasharray:`${length}`,strokeDashoffset:0}],{duration:1000,delay:180,easing:'ease-out'});
    });
   }else reveal(target);
  }),{threshold:.12,rootMargin:'0px 0px -25px 0px'});
  document.querySelectorAll('.case-hero h1,.case-lead,.project-facts,.hero-screen,.section-copy,.impact-strip,.outcomes,.user-columns,.concepts,.business-decline,.funnel,.visual-decision,.video-block').forEach(el=>observer.observe(el));
 }
 // A slim reading-progress line follows the existing section navigation.
 const nav=document.querySelector('.case-nav');
 let pending=false;
 const update=()=>{
  pending=false;
  const hero=document.querySelector('.case-hero');
  const start=hero.offsetTop+hero.offsetHeight;
  const range=document.documentElement.scrollHeight-innerHeight-start;
  nav.style.setProperty('--reading-progress',Math.max(0,Math.min(1,(scrollY-start)/Math.max(1,range))));
 };
 const schedule=()=>{if(!pending){pending=true;requestAnimationFrame(update)}};
 if(nav){addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule);update()}
 preference.addEventListener('change',()=>{if(preference.matches){active.forEach(a=>a.finish());counted.forEach(f=>f())}});
})();
